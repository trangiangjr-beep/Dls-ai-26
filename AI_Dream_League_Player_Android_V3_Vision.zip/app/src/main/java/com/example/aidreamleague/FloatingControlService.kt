package com.example.aidreamleague

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingControlService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var status: TextView? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(7, buildNotification())
        showFloatingPanel()
    }

    private fun showFloatingPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xEE17283A.toInt())
        }

        val title = TextView(this).apply {
            text = "⚽ AI FOOTBALL"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        status = TextView(this).apply {
            text = "AI: ĐANG CHỜ"
            textSize = 13f
            setTextColor(0xFF9FE7C5.toInt())
        }
        val start = Button(this).apply {
            text = "START AI"
            setOnClickListener {
                status?.text = "AI: ĐÃ BẬT (DEMO)"
            }
        }
        val stop = Button(this).apply {
            text = "STOP AI"
            setOnClickListener {
                status?.text = "AI: ĐÃ DỪNG"
            }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(start)
        layout.addView(stop)
        panel = layout

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 140
        }

        windowManager?.addView(layout, params)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "ai_overlay", "AI Floating Controls", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "ai_overlay")
                .setContentTitle("AI Dream League Player")
                .setContentText("Bảng điều khiển nổi đang chạy")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("AI Dream League Player")
                .setContentText("Bảng điều khiển nổi đang chạy")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build()
        }
    }

    override fun onDestroy() {
        panel?.let { windowManager?.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
