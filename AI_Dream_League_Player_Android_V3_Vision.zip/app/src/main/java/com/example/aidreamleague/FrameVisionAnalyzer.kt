package com.example.aidreamleague

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class VisionResult(
    val pitchCoverage: Float,
    val likelyBallX: Float?,
    val likelyBallY: Float?,
    val whiteCandidateCount: Int,
    val confidence: Float,
    val summary: String
)

/**
 * Bộ phân tích hình ảnh heuristic để kiểm tra đường ống dữ liệu.
 * Không phải mô hình nhận diện đã huấn luyện; màu áo, sân, ánh sáng,
 * giao diện và hiệu ứng trong game có thể gây nhầm lẫn.
 */
class FrameVisionAnalyzer {
    fun analyze(bitmap: Bitmap): VisionResult {
        if (bitmap.width < 16 || bitmap.height < 16) {
            return VisionResult(0f, null, null, 0, 0f, "Khung hình quá nhỏ.")
        }

        val step = max(2, min(bitmap.width, bitmap.height) / 180)
        var total = 0
        var green = 0
        val candidates = mutableListOf<Pair<Int, Int>>()

        var y = bitmap.height / 8
        while (y < bitmap.height * 7 / 8) {
            var x = bitmap.width / 12
            while (x < bitmap.width * 11 / 12) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff
                total++

                // Ước lượng điểm ảnh màu xanh sân cỏ; chỉ là heuristic.
                val isGreen = g > 55 && g > r * 1.12 && g > b * 1.08
                if (isGreen) green++

                // Ứng viên trắng nhỏ: bóng có thể có màu sáng, nhưng vạch sân/UI cũng vậy.
                val bright = r > 205 && g > 205 && b > 205
                val lowSpread = max(r, max(g, b)) - min(r, min(g, b)) < 38
                if (bright && lowSpread) candidates.add(x to y)
                x += step
            }
            y += step
        }

        val coverage = if (total == 0) 0f else green.toFloat() / total
        val plausible = candidates.filter { (x, py) ->
            x in (bitmap.width * 0.12).toInt()..(bitmap.width * 0.88).toInt() &&
            py in (bitmap.height * 0.15).toInt()..(bitmap.height * 0.85).toInt()
        }

        // Chỉ đưa ra điểm sáng trung tâm như một vị trí ứng viên, không khẳng định đó là bóng.
        val candidate = plausible.minByOrNull { (x, py) ->
            abs(x - bitmap.width / 2) + abs(py - bitmap.height / 2)
        }

        val confidence = when {
            coverage > 0.18f && candidate != null -> 0.30f
            coverage > 0.18f -> 0.22f
            else -> 0.08f
        }

        return VisionResult(
            pitchCoverage = coverage,
            likelyBallX = candidate?.first?.toFloat()?.div(bitmap.width),
            likelyBallY = candidate?.second?.toFloat()?.div(bitmap.height),
            whiteCandidateCount = plausible.size,
            confidence = confidence,
            summary = if (coverage > 0.18f)
                "Có vùng màu giống sân cỏ; cần mô hình đã huấn luyện để xác nhận bóng."
            else
                "Chưa nhận diện rõ sân bóng trong khung hình."
        )
    }
}
