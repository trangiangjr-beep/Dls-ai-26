package com.example.aidreamleague

import android.content.Intent
import android.net.Uri
import android.media.projection.MediaProjectionManager
import android.app.Activity
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Navy = Color(0xFF101B2B)
private val Panel = Color(0xFF1C2D42)
private val Green = Color(0xFF19B77A)

class MainActivity : ComponentActivity() {
    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, ScreenVisionService::class.java).apply {
                    putExtra(ScreenVisionService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenVisionService.EXTRA_RESULT_DATA, result.data)
                }
                ContextCompat.startForegroundService(this, serviceIntent)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Green, background = Navy, surface = Panel
            )) {
                Dashboard(
                    onEnableOverlay = { requestOverlayPermission() },
                    onStartOverlay = { startFloatingService() },
                    onStopOverlay = {
                        stopService(Intent(this, FloatingControlService::class.java))
                        stopService(Intent(this, ScreenVisionService::class.java))
                    },
                    onStartVision = { requestScreenCapture() }
                )
            }
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun startFloatingService() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        ContextCompat.startForegroundService(
            this, Intent(this, FloatingControlService::class.java)
        )
    }
}

@Composable
fun Dashboard(
    onEnableOverlay: () -> Unit,
    onStartOverlay: () -> Unit,
    onStopOverlay: () -> Unit,
    onStartVision: () -> Unit
) {
    var aiEnabled by remember { mutableStateOf(false) }
    var selectedMode by remember { mutableStateOf("Cửa sổ nổi") }
    var aiDecision by remember { mutableStateOf("Chưa chạy phân tích") }
    var aiReason by remember { mutableStateOf("Nhấn CHẠY THỬ AI để kiểm tra bộ não ra quyết định.") }
    val decisionEngine = remember { FootballDecisionEngine() }

    Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
        Column(
            modifier = Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SportsSoccer, null, tint = Green, modifier = Modifier.size(38.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("AI FOOTBALL", fontSize = 23.sp, color = Color.White)
                    Text("DREAM LEAGUE PLAYER", color = Color.LightGray, fontSize = 12.sp)
                }
                AssistChip(onClick = {}, label = { Text("V1.0") })
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("TRẠNG THÁI AI", color = Color.LightGray)
                    Text(if (aiEnabled) "ĐANG HOẠT ĐỘNG" else "ĐANG CHỜ",
                        color = if (aiEnabled) Green else Color.White, fontSize = 22.sp)
                    Text("Bản V1 cung cấp bảng điều khiển và khung tích hợp AI.",
                        color = Color.LightGray, fontSize = 13.sp)
                }
            }

            Text("CHẾ ĐỘ SỬ DỤNG", color = Color.White)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Cửa sổ nổi", "Ứng dụng độc lập").forEach { mode ->
                    FilterChip(
                        selected = selectedMode == mode,
                        onClick = { selectedMode = mode },
                        label = { Text(mode) }
                    )
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    FeatureRow(Icons.Default.Visibility, "Nhận diện màn hình", "Khung tích hợp Computer Vision")
                    FeatureRow(Icons.Default.Psychology, "Phân tích tình huống", "Khung tích hợp mô hình AI")
                    FeatureRow(Icons.Default.SportsScore, "Chiến thuật", "Chuyền bóng · rê bóng · sút bóng")
                    FeatureRow(Icons.Default.StopCircle, "Dừng khẩn cấp", "Người dùng luôn có quyền dừng")
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("BỘ NÃO AI – CHẠY THỬ", color = Green)
                    Text(aiDecision, color = Color.White, fontSize = 19.sp)
                    Text(aiReason, color = Color.LightGray, fontSize = 13.sp)
                    OutlinedButton(
                        onClick = {
                            // Dữ liệu mô phỏng để kiểm tra bộ ra quyết định.
                            // Khi tích hợp vision, thay observation này bằng dữ liệu nhận diện thật.
                            val sample = MatchObservation(
                                ballX = 0.72f, ballY = 0.50f,
                                ownGoalX = 0.05f, ownGoalY = 0.50f,
                                opponentGoalX = 0.96f, opponentGoalY = 0.50f,
                                players = listOf(
                                    PlayerObservation(0.82f, 0.43f, true),
                                    PlayerObservation(0.76f, 0.55f, false),
                                    PlayerObservation(0.88f, 0.62f, false)
                                ),
                                phase = GamePhase.ATTACK,
                                possessionConfidence = 0.8f,
                                frameConfidence = 0.95f
                            )
                            val result = decisionEngine.decide(sample)
                            aiDecision = "ĐỀ XUẤT: ${result.action}"
                            aiReason = "${result.reason} Độ tin cậy: ${(result.confidence * 100).toInt()}%"
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Psychology, null)
                        Spacer(Modifier.width(8.dp))
                        Text("CHẠY THỬ AI")
                    }
                }
            }

            OutlinedButton(
                onClick = onStartVision,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Visibility, null)
                Spacer(Modifier.width(8.dp))
                Text("CHO PHÉP AI QUAN SÁT MÀN HÌNH")
            }

            Button(
                onClick = {
                    onEnableOverlay()
                    onStartOverlay()
                    aiEnabled = true
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(8.dp))
                Text("START FLOATING AI")
            }

            OutlinedButton(
                onClick = {
                    onStopOverlay()
                    aiEnabled = false
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Stop, null)
                Spacer(Modifier.width(8.dp))
                Text("STOP AI")
            }

            Text(
                "Vision V3 đang dùng heuristic màu để thử đường ống hình ảnh, chưa phải nhận diện bóng/cầu thủ chính xác và chưa tự điều khiển game.",
                color = Color.LightGray, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun FeatureRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Color.White)
            Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
        }
    }
}
