package com.example.aidreamleague

/**
 * Bộ não ra quyết định bóng đá.
 *
 * Đầu vào là dữ liệu đã được một mô-đun vision nhận diện từ khung hình.
 * Đầu ra là quyết định/đề xuất có cấu trúc; không tự gửi thao tác chạm
 * vào game và không can thiệp cơ chế chống gian lận.
 */
enum class GamePhase { ATTACK, DEFENCE, LOOSE_BALL, UNKNOWN }
enum class AiAction { SHOOT, PASS, DRIBBLE, DEFEND, MOVE_TO_BALL, HOLD, NEED_MORE_VISION }

data class PlayerObservation(
    val x: Float,                 // tọa độ chuẩn hóa 0..1
    val y: Float,
    val isTeammate: Boolean,
    val confidence: Float = 1f
)

data class MatchObservation(
    val ballX: Float?,
    val ballY: Float?,
    val ownGoalX: Float,
    val ownGoalY: Float,
    val opponentGoalX: Float,
    val opponentGoalY: Float,
    val players: List<PlayerObservation>,
    val phase: GamePhase,
    val possessionConfidence: Float,
    val frameConfidence: Float
)

data class AiDecision(
    val action: AiAction,
    val reason: String,
    val confidence: Float,
    val suggestedTargetX: Float? = null,
    val suggestedTargetY: Float? = null
)

class FootballDecisionEngine {

    fun decide(o: MatchObservation): AiDecision {
        if (o.frameConfidence < 0.55f || o.ballX == null || o.ballY == null) {
            return AiDecision(
                AiAction.NEED_MORE_VISION,
                "Chưa nhận diện chắc chắn được bóng hoặc khung hình.",
                o.frameConfidence.coerceIn(0f, 1f)
            )
        }

        val ballX = o.ballX.coerceIn(0f, 1f)
        val ballY = o.ballY.coerceIn(0f, 1f)
        val validPlayers = o.players.filter { it.confidence >= 0.5f }
        val teammates = validPlayers.filter { it.isTeammate }
        val opponents = validPlayers.filter { !it.isTeammate }

        return when (o.phase) {
            GamePhase.ATTACK -> attack(o, ballX, ballY, teammates, opponents)
            GamePhase.DEFENCE -> defend(o, ballX, ballY, teammates)
            GamePhase.LOOSE_BALL -> AiDecision(
                AiAction.MOVE_TO_BALL,
                "Bóng tự do: ưu tiên áp sát vị trí bóng.",
                0.72f, ballX, ballY
            )
            GamePhase.UNKNOWN -> AiDecision(
                AiAction.HOLD,
                "Chưa xác định được trạng thái trận đấu; giữ an toàn và quan sát thêm.",
                0.4f
            )
        }
    }

    private fun attack(
        o: MatchObservation,
        bx: Float,
        by: Float,
        teammates: List<PlayerObservation>,
        opponents: List<PlayerObservation>
    ): AiDecision {
        val goalDistance = distance(bx, by, o.opponentGoalX, o.opponentGoalY)
        val nearestOpponent = opponents.minOfOrNull { distance(bx, by, it.x, it.y) }
            ?: 1f

        // Chỉ đề xuất sút khi ở vùng gần khung thành và có khoảng trống tương đối.
        if (goalDistance < 0.24f && nearestOpponent > 0.075f) {
            return AiDecision(
                AiAction.SHOOT,
                "Đang ở tương đối gần khung thành và có khoảng trống để dứt điểm.",
                0.78f, o.opponentGoalX, o.opponentGoalY
            )
        }

        // Chọn đồng đội ở phía trước, ưu tiên khoảng cách vừa phải và ít đối thủ gần.
        val passTarget = teammates
            .filter { it.x > bx + 0.04f }
            .map { p ->
                val pressure = opponents.minOfOrNull { distance(p.x, p.y, it.x, it.y) } ?: 1f
                val forward = p.x - bx
                val score = forward * 1.2f + pressure * 0.8f - distance(bx, by, p.x, p.y) * 0.25f
                p to score
            }
            .maxByOrNull { it.second }?.first

        if (passTarget != null && (nearestOpponent < 0.10f || goalDistance > 0.32f)) {
            return AiDecision(
                AiAction.PASS,
                "Có đồng đội ở phía trước với khoảng trống phù hợp.",
                0.70f, passTarget.x, passTarget.y
            )
        }

        return AiDecision(
            AiAction.DRIBBLE,
            "Chưa có cơ hội sút rõ ràng; tiếp tục tiến bóng và chờ tình huống tốt hơn.",
            0.65f, o.opponentGoalX, by
        )
    }

    private fun defend(
        o: MatchObservation,
        bx: Float,
        by: Float,
        teammates: List<PlayerObservation>
    ): AiDecision {
        val nearestDefender = teammates.minByOrNull {
            distance(it.x, it.y, bx, by)
        }
        return AiDecision(
            AiAction.DEFEND,
            "Ưu tiên giữ vị trí phòng ngự và gây áp lực lên khu vực bóng.",
            0.70f,
            nearestDefender?.x ?: bx,
            nearestDefender?.y ?: by
        )
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2
        val dy = y1 - y2
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }
}
