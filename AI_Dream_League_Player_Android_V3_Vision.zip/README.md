# AI Dream League Player — Android starter

Bộ khung Android Kotlin/Jetpack Compose cho ứng dụng điều khiển AI hỗ trợ Dream League Soccer.

## Yêu cầu
- Android Studio Ladybug hoặc mới hơn
- JDK 17
- Android SDK 35
- Điện thoại Android 8.0 trở lên để chạy ứng dụng

## Mở dự án
1. Giải nén ZIP.
2. Android Studio → Open → chọn thư mục `AIDreamLeaguePlayer`.
3. Chờ Gradle Sync.
4. Chạy app trên thiết bị Android.

## Chức năng hiện có
- Dashboard Compose.
- Yêu cầu quyền overlay.
- Foreground service và bảng điều khiển nổi.
- Nút START/STOP demo.

## Chưa có trong V1
- Chưa chụp/đọc màn hình game.
- Chưa có mô hình computer vision.
- Chưa tự thao tác điều khiển game.
- Nút START hiện chỉ đổi trạng thái demo.

## Hướng phát triển an toàn
Có thể bổ sung luồng MediaProjection có thông báo/đồng ý rõ ràng, xử lý frame bằng OpenCV hoặc mô hình nhận diện được cấp phép, và chỉ cung cấp phân tích/đề xuất hoặc kiểm thử trong môi trường offline được phép. Không vượt qua anti-cheat hoặc tự động hóa trận đấu trực tuyến.


## Bộ não ra quyết định (bản thử nghiệm)
`FootballDecisionEngine.kt` nhận `MatchObservation` và đề xuất một hành động:
- SHOOT, PASS, DRIBBLE, DEFEND, MOVE_TO_BALL, HOLD hoặc NEED_MORE_VISION.
- Dashboard có nút CHẠY THỬ AI với tình huống mô phỏng.

Dữ liệu hiện tại là dữ liệu mẫu để kiểm tra logic. Chưa có nhận diện khung hình thực tế, chưa tự điều khiển game và chưa được xem là AI tự chơi hoàn chỉnh. Để tiến tới tự chơi cần mô-đun vision được kiểm thử, dữ liệu huấn luyện/đánh giá phù hợp và tích hợp điều khiển được game cho phép; không dùng trong trận đấu trực tuyến nếu vi phạm điều khoản game.


## Camera Vision V3 (prototype)
- Thêm quyền MediaProjection với hộp thoại đồng ý hệ thống.
- `ScreenVisionService` nhận khung hình màn hình và ghi kết quả phân tích vào Logcat.
- `FrameVisionAnalyzer` ước lượng vùng xanh giống sân và các điểm ảnh sáng có thể là ứng viên bóng.
- Trong app, nhấn **CHO PHÉP AI QUAN SÁT MÀN HÌNH** và xác nhận hộp thoại Android để bắt đầu.
- Dừng bằng **STOP AI** (dừng overlay và dịch vụ vision).

Lưu ý quan trọng: đây là heuristic thử nghiệm, không phải model computer vision được huấn luyện. Vạch sân, giao diện, ánh sáng và áo đấu có thể gây nhận diện nhầm. Chưa nhận diện cầu thủ đáng tin cậy, chưa xác định đội/pha bóng chắc chắn, chưa tự điều khiển game. Kiểm tra log bằng tag `AIDreamLeagueVision` trong Android Studio. Việc chia sẻ màn hình luôn cần người dùng xác nhận qua hộp thoại Android.
